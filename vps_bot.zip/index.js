
const { Client, GatewayIntentBits, SlashCommandBuilder, REST, Routes } = require('discord.js');
require('dotenv').config();
const { exec } = require('child_process');

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commands = [
  new SlashCommandBuilder().setName('deploy').setDescription('Crea una VPS de 8GB RAM y 3 CPU cores'),
  new SlashCommandBuilder().setName('deployadmin').setDescription('Crea una VPS personalizada (solo admins)')
    .addIntegerOption(opt => opt.setName('ram').setDescription('RAM en GB').setRequired(true))
    .addIntegerOption(opt => opt.setName('cpu').setDescription('Cores de CPU').setRequired(true)),
  new SlashCommandBuilder().setName('editvpsadmin').setDescription('Editar VPS de un usuario (solo admins)')
    .addStringOption(opt => opt.setName('usuario').setDescription('ID del usuario').setRequired(true))
    .addIntegerOption(opt => opt.setName('ram').setDescription('Nueva RAM').setRequired(true))
    .addIntegerOption(opt => opt.setName('cpu').setDescription('Nueva CPU').setRequired(true)),
  new SlashCommandBuilder().setName('deploy128').setDescription('VPS gratis con 128 GB de RAM 😱 (broma)'),
  new SlashCommandBuilder().setName('deletevps').setDescription('Eliminar tu VPS')
].map(cmd => cmd.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

client.once('ready', async () => {
  console.log(`✅ Bot conectado como ${client.user.tag}`);
  await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
  console.log('✅ Comandos registrados');
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const userId = interaction.user.id;
  const containerName = `vps_${userId}`;

  if (interaction.commandName === 'deploy') {
    await interaction.reply('🛠️ Creando tu VPS (8GB RAM, 3 CPU)...');

    const cmd = `docker run -dit --name ${containerName} --memory=8g --cpus=3 ubuntu bash`;
    exec(cmd, (err) => {
      if (err) return interaction.editReply('❌ Error creando VPS');
      exec(`tmate -S /tmp/tmate_${userId}.sock new-session -d && tmate -S /tmp/tmate_${userId}.sock wait tmate-ready && tmate -S /tmp/tmate_${userId}.sock display -p '#{tmate_ssh}'`, (err2, stdout) => {
        if (err2) return interaction.editReply('✅ VPS creada, pero no se pudo generar acceso SSH.');
        interaction.user.send(`🔐 SSH para tu VPS: 
\`\`\`
${stdout}
\`\`\``);
        interaction.editReply('✅ VPS creada. Revisa tu MD para el acceso SSH.');
      });
    });
  }

  if (interaction.commandName === 'deployadmin') {
    if (!interaction.member.permissions.has('Administrator')) return interaction.reply({ content: '❌ Solo administradores.', ephemeral: true });

    const ram = interaction.options.getInteger('ram');
    const cpu = interaction.options.getInteger('cpu');
    const cmd = `docker run -dit --name ${containerName} --memory=${ram}g --cpus=${cpu} ubuntu bash`;
    await interaction.reply(`🛠️ Creando VPS de ${ram}GB RAM y ${cpu} CPU...`);
    exec(cmd, (err) => {
      if (err) return interaction.editReply('❌ Error creando VPS personalizada.');
      exec(`tmate -S /tmp/tmate_${userId}.sock new-session -d && tmate -S /tmp/tmate_${userId}.sock wait tmate-ready && tmate -S /tmp/tmate_${userId}.sock display -p '#{tmate_ssh}'`, (err2, stdout) => {
        if (err2) return interaction.editReply('✅ VPS creada, pero no se pudo generar acceso SSH.');
        interaction.user.send(`🔐 SSH para tu VPS: 
\`\`\`
${stdout}
\`\`\``);
        interaction.editReply('✅ VPS personalizada creada. Revisa tu MD para el acceso SSH.');
      });
    });
  }

  if (interaction.commandName === 'editvpsadmin') {
    if (!interaction.member.permissions.has('Administrator')) return interaction.reply({ content: '❌ Solo administradores.', ephemeral: true });

    const target = interaction.options.getString('usuario');
    const ram = interaction.options.getInteger('ram');
    const cpu = interaction.options.getInteger('cpu');
    const name = `vps_${target}`;

    exec(`docker update --memory=${ram}g --cpus=${cpu} ${name}`, (err) => {
      if (err) return interaction.reply('❌ Error actualizando la VPS.');
      interaction.reply(`✅ VPS de <@${target}> actualizada a ${ram}GB RAM, ${cpu} CPU.`);
    });
  }

  if (interaction.commandName === 'deploy128') {
    await interaction.reply('🧠 Preparando una VPS con 128 GB de RAM...');
    interaction.user.send('😄 ¡Bromista! No hay VPS de 128 GB. ¡Te la creíste!');
  }

  if (interaction.commandName === 'deletevps') {
    await interaction.reply('🗑️ Eliminando tu VPS...');
    exec(`docker rm -f ${containerName}`, (err) => {
      if (err) return interaction.editReply('❌ No se pudo eliminar la VPS.');
      interaction.editReply('✅ Tu VPS ha sido eliminada.');
    });
  }
});

client.login(process.env.DISCORD_TOKEN);
